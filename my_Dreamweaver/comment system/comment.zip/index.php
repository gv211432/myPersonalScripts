<!DOCTYPE html>
<html>
<head>
	<title>Comment Box</title>
<link rel="stylesheet" type="text/css" href="">
<script type="text/javascript" src="uncompressed-jquery.js"></script>
<script type="text/javascript" src="script.js"></script>
</head>
<body>

	<div class="wrapper">
		<div class="page-data">Page data is in here</div>
		<div class="comment-wrapper"><h3>User feedback...</h3>
		.

		</div>


	</div>

</body>xa
</html>